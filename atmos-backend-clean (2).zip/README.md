# Atmos Backend

Node.js/Express backend for Atmos Macro Intelligence Terminal.

## Endpoints
- GET /              — health check
- GET /api/cot       — COT data (CFTC). ?asset=GOLD|SILVER|OIL|EURO|BTC etc.
- GET /api/rates     — Central bank rates
- GET /api/news      — Geopolitical news (requires GNEWS_API_KEY)
- GET /api/politicians — Politician trades (SEC EDGAR)

## Environment Variables
- GNEWS_API_KEY — from gnews.io

## Deploy
Railway detects package.json automatically. Just connect this repo.
